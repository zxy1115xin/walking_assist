/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: iirFilter_data.h
 *
 * MATLAB Coder version            : 5.3
 * C/C++ source code generated on  : 10-Jul-2022 17:29:38
 */

#ifndef IIRFILTER_DATA_H
#define IIRFILTER_DATA_H

/* Include Files */
#include "iirFilter_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern dspcodegen_BiquadFilter Hd;
extern boolean_T isInitialized_iirFilter;

#endif
/*
 * File trailer for iirFilter_data.h
 *
 * [EOF]
 */
