/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: iirFilter_initialize.h
 *
 * MATLAB Coder version            : 5.3
 * C/C++ source code generated on  : 10-Jul-2022 17:29:38
 */

#ifndef IIRFILTER_INITIALIZE_H
#define IIRFILTER_INITIALIZE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void iirFilter_initialize(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for iirFilter_initialize.h
 *
 * [EOF]
 */
