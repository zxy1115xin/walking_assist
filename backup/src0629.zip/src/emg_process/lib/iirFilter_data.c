/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: iirFilter_data.c
 *
 * MATLAB Coder version            : 5.3
 * C/C++ source code generated on  : 10-Jul-2022 17:29:38
 */

/* Include Files */
#include "iirFilter_data.h"

/* Variable Definitions */
dspcodegen_BiquadFilter Hd;

boolean_T isInitialized_iirFilter = false;

/*
 * File trailer for iirFilter_data.c
 *
 * [EOF]
 */
