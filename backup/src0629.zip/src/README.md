# 备忘录

## Git: 

### 账户信息

账户：**xinyez@hust.edu.cn**

密码：520qq520qq

密钥：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 

### Git相关操作代码

git branch -a		查看所有分支

git checkout  xin		切换分支

git pull origin xin		通过网络更新本地代码

git add . 		提交之前暂存

git commit -m  "本次修改注释"		提交修改

git push origin xin		上传本地修改







